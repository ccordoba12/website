This directory contains a general simulation environment for any
cellular automata with Margolus neighborhood. Here it has been used
to develop a cellular automata capable of reproducing the flow of sand
through a funnel. The algorithm was developed in Mathematica 4.0 and
its description is presented as a Mathematica notebook.

All these files are part of thesis "Estudio computacional de los
materiales granulares por medio de aut�matas celulares".
� 2002 Carlos A. C�rdoba Ch. All right reserved.

You can contact the author at this email address: ccordoba12@gmail.com.
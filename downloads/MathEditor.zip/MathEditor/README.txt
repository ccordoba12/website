This package provides a better syntax highlighting for the FrontEnd.
It highlights braces, brackets, system and personal functions,
and it lets you apply a personalized indentation to any cell too.

====== TO INSTALL THE PACKAGE ======

Move the MathEditor dir to $UserAddOnsDirectory/Applications

NOTE: $UserAddOnsDirectory is a directory where Mathematica looks for
personal packages. Please evaluate it (with the $ symbol included) in
Mathematica.
Typical results are:
a) On Windows: C:\Documents and Settings\your_name_account\Data programs\Mathematica
b) On Linux: /home/your_user_login/.Mathematica

====== TO USE THE PACKAGE ======

Open the provided palettes (Beautification and Indentation) and apply them
to a notebook to see the results.

You can also use the keyboard shortcut CTRL + H to highlight a cell.

If you have any suggesttions or want to report bugs,
please write us to ccordoba12@gmail.com.

====== WARNING ======

This package doesn't work with the native highlighting of the FrontEnd. Please disable
it before using our package. Failure to do it can crash Mathematica. You've warned!

-------------------------------------------------

DISCLAIMER - This software is provided "as is", no responsibility
                         will be taken from proper or improper use. It cannot be
		         confirmed that this software will or will not work as is or isn't
		         directed, and has not been proven or disproven to do so.
                         WE WILL TAKE NO RESPONSIBILITY FOR ANY LOSS OR DAMAGE
		         TO YOUR WORK.

Please don't use this software for your professional work. It is still beta software
and it has not been well tested.

This software is distributed under the terms of the GNU General Public License v2.
For a copy of the license agreement see the archive COPYING.txt distributed
with this package or the web page http://www.gnu.org/copyleft/gpl.html

Copyright (c) 2009 Carlos Córdoba and Javier Ospina.

(* :Author: Carlos Cordoba *)

If[! MemberQ[$Packages, "MathEditor`"],
     System`Private`p = Unprotect[$Packages];
     PrependTo[$Packages, "MathEditor`"];
     Protect @@ System`Private`p
];

(* Declarations for package MathEditor`Highlighting` *)

DeclarePackage["MathEditor`Highlighting`",{"beautifyCell", "unbeautifyCell", "beautifyNotebook", "unbeautifyNotebook", "beautifyNotebookInNewNotebook"}]

(* End of Master package *)
